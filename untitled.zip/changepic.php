<?php
session_start();
$check = $_SESSION['checkvalue'];
$id = $_SESSION['id'];
echo $check;
if($check === 'okok') {
    require 'connect.php';
    $dbs = "SELECT * from ans_check  WHERE ques_no = :id";
    $st = $dbh->prepare($dbs);
    $st->bindParam(':id',$id);
    $st->execute();
    $st->setFetchMode(PDO::FETCH_ASSOC);
    $result=$st->fetchAll();
    foreach ($result as $res) {
        echo "successful";
        $img =  $res['qimage'];
        echo "<img src='$img'>";
        $_SESSION['id'] = $id + 1;
    }
    $id++;
    echo $id;
    $q = $_REQUEST["q"];
    echo $q;
    echo date("h:i:sa");

}else{
    echo 'go and login first';
}