<?php
session_start();
$uname = $_POST['username'];
$upass = $_POST['password'];

try {
    require 'connect.php';
    $q = "SELECT * from login WHERE login_id = :id AND password = :pass";
    $sth = $dbh->prepare($q);
    $sth->bindParam(':id', $uname);
    $sth->bindParam(':pass',$upass);
    $sth->execute();
    $rowcount = $sth->rowCount();
    echo $rowcount;

    if($rowcount == 1)
    {
        $_SESSION['checkvalue'] = 'okok';
        $_SESSION['username'] = $uname;
        $_SESSION['id'] = 1;
        echo "login successfull";
        header('Location: mypage.html');
    }
    $dbh = null;
}
catch (PDOException $e)
{
    error_log('PDOEXCP - '.$e->getMessage(),0);
    http_response_code(500);
    die('error establishing connection with database');
}
